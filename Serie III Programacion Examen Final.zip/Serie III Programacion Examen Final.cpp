/*Maderlaine Vanessa Aldana Martinez Carne 0909-20-6881
Ingeniera en Sistemas 3er. Semestre Universidad Mariano Galvez
Examen Final Programaci�n I*/

//Declaraci�n de librerias
#include <iostream>
#include <string.h>
#include <stdlib.h>

using namespace std;

//Declaraci�n de variables
struct Cola{
	int front;
	int final;
	int ability;
	char *array;
	
};

struct Cola* crearCola(int ability){
	
	struct Cola* cola = (struct Cola*)malloc(sizeof(struct Cola)); //Reservamos el bloque de memoria
	cola->ability = ability; //Determina el tama�o de la cola
	cola->front = -1; //Determina el valor en el tope de la cola
	cola->final=0;//Determina el valor del final de la cola
	cola->array = (char*)malloc(cola->ability*sizeof(char)); //Determinamos un array que almacenara los datos
	return cola;
}

//funci�n que determina si la pila esta vacia
int vacia(Cola q){
	
	if (q.final==0) 
		return (1);
	
 return(0);
}

//funci�n que determina si la cola esta llena
int llena(Cola *q){
	if (q->final==q->ability) return (1);
	
 return(0);
}

//funci�n de ingreso de datos
void ingresar(Cola *q, char *dato){

	q->array[q->final]=*dato;
 	q->final++;
 	
}

//funci�n programada para eliminar los elementos de la cola 
string eliminar(Cola *cola){
	
	int i;
	string x;
	
	x=cola->array[0];
	
	for(i=0;i<cola->final-1;i++)
		cola->array[i]=cola->array[i+1];
		
	cola->final--;
	
	return(x);
	
}

//funci�n para visualizar los datos ingresados a la cola
void visualizar(struct Cola* q){
	
	struct Cola p=*q;
    int i;
    
	if(!vacia(p)){
    	
	    cout<<"\n\tVisualizaci�n de todos los elementos de la cola\n";
	    for(i=0;i<q->final;i++)
	    	cout<<q->array<<endl;
	}
	else
		printf("\nNo se encuentra ningun dato\n");
		
}


int main(int argc, char** argv) {
	
	int option;
	int size;
	char *name;
	struct Cola* cola;
	
	do{
		system("cls");
		cout<<"\n*****************************************"<<endl;
		cout<<"*           MENU DE OPCIONES              *"<<endl;
		cout<<"*******************************************"<<endl;
		cout<<"1.-* Establecer tama�o del array          *"<<endl;
		cout<<"2.-* Funcion QUEUE                        *"<<endl;
		cout<<"3.-* Funcion ENQUEUE                      *"<<endl;
		cout<<"4.-* Mostrar COLA                         *"<<endl;
		cout<<"5.-* Finalizar Programa                   *"<<endl;
		cout<<"*******************************************"<<endl;
		cout<<"\n\n\tOpcion: ";
		cin>>option;
		
		switch(option){
			case 1: cout<<"\n\tIngresar el tama�o del arreglo: ";
					cin>>size;
					cola=crearCola(size); //Creamos la cola
					break;
				
			case 2:	cout<<"\n\tIngresa el nombre a registrar: ";
			name = (char*)malloc(sizeof(char)); //Creamos un array que almacena los datos
					cin>>name;
					ingresar(cola, name);
					break;
			
			case 3:	cout<<"\n\tEliminar un elemento de la cola";
					eliminar(cola);
					cout<<"\n\tSe ha eliminado un elemento";
					break;
			
			case 4:	cout<<"\n\tVisualizaci�n de los elementos de la cola\n";
					visualizar(cola);
					system("pause");
					break;
			
			case 5:	cout<<"\n\tFinalizar el programa:";
					break;
			
			default:	cout<<"\n\tOpcion incorrecta";
					break;

		}
		
	}while(option!=5);
	
	return 0;
}

/*Maderlaine Vanessa Aldana Martinez Carne 0909-20-6881
Ingeniera en Sistemas 3er. Semestre Universidad Mariano Galvez
Examen Final Programaci�n I*/

